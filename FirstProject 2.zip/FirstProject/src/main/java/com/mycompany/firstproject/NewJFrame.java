package com.mycompany.firstproject;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class NewJFrame extends javax.swing.JFrame {

    private static final String DATABASE_URL = "jdbc:sqlite:Libraries/organizations.db";
    
    public NewJFrame() {
        initComponents();
        makeTable();
        populateTable();

        WhatCategory.addItem("Everything");
        WhatCategory.addItem("Name Of Orginization");
        WhatCategory.addItem("Type Of Orginization");
        WhatCategory.addItem("Dollar Valuation");
        WhatCategory.addItem("Contact Email");
        WhatCategory.addItem("Year Founded");
        WhatCategory.addItem("Name of CEO");
        WhatCategory.addItem("Contact Phone Number");
        
        
    }
    private String name;
    private boolean typeOfOrginization;
    private String dollarValuation;
    private String ceo;
    private String contactEmail;
    private String yearOfFounding;
    long longContactPhoneNumber = 0;
    String currentlySearched = "";
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        ViewAndSort = new javax.swing.JPanel();
        Viewing = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        SortByValue = new javax.swing.JButton();
        WhatCategory = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        SearchFor = new javax.swing.JTextField();
        EditButton = new javax.swing.JButton();
        SortByYear = new javax.swing.JButton();
        SortOnlyNonProfits = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        EnterOrginization = new javax.swing.JPanel();
        nameOfOrginizationTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dollarValuationTextField = new javax.swing.JTextField();
        nameOfCEOTextField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        contactEmailTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        contactPhoneNumberTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        yearOfFoundingTextField = new javax.swing.JTextField();
        isNonProfit = new javax.swing.JCheckBox();
        submitButton = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(2792, 1122));

        jTabbedPane1.setForeground(new java.awt.Color(137, 150, 171));
        jTabbedPane1.setMaximumSize(new java.awt.Dimension(2792, 1122));

        ViewAndSort.setMaximumSize(new java.awt.Dimension(2792, 1122));

        Viewing.setMaximumSize(new java.awt.Dimension(2792, 1122));

        jLabel9.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(60, 63, 65));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Sort By");

        SortByValue.setBackground(new java.awt.Color(187, 187, 187));
        SortByValue.setForeground(new java.awt.Color(123, 139, 166));
        SortByValue.setText("Company Valuation");
        SortByValue.setMaximumSize(new java.awt.Dimension(119, 23));
        SortByValue.setMinimumSize(new java.awt.Dimension(119, 23));
        SortByValue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SortByValueActionPerformed(evt);
            }
        });

        WhatCategory.setForeground(new java.awt.Color(60, 63, 65));
        WhatCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WhatCategoryActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(60, 63, 65));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Search For");

        SearchFor.setBackground(new java.awt.Color(244, 244, 244));
        SearchFor.setForeground(new java.awt.Color(123, 139, 166));
        SearchFor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchForActionPerformed(evt);
            }
        });

        EditButton.setBackground(new java.awt.Color(187, 187, 187));
        EditButton.setFont(new java.awt.Font("Osaka", 0, 18)); // NOI18N
        EditButton.setForeground(new java.awt.Color(123, 139, 166));
        EditButton.setText("Edit");
        EditButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditButtonActionPerformed(evt);
            }
        });

        SortByYear.setBackground(new java.awt.Color(187, 187, 187));
        SortByYear.setForeground(new java.awt.Color(123, 139, 166));
        SortByYear.setText("Year Founded");
        SortByYear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SortByYearActionPerformed(evt);
            }
        });

        SortOnlyNonProfits.setBackground(new java.awt.Color(187, 187, 187));
        SortOnlyNonProfits.setForeground(new java.awt.Color(123, 139, 166));
        SortOnlyNonProfits.setText("Company Type");
        SortOnlyNonProfits.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SortOnlyNonProfitsActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Osaka", 0, 30)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(60, 63, 65));
        jLabel13.setText("Edit Search and Sort");

        javax.swing.GroupLayout ViewingLayout = new javax.swing.GroupLayout(Viewing);
        Viewing.setLayout(ViewingLayout);
        ViewingLayout.setHorizontalGroup(
            ViewingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ViewingLayout.createSequentialGroup()
                .addContainerGap(1129, Short.MAX_VALUE)
                .addGroup(ViewingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ViewingLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addGap(1094, 1094, 1094))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ViewingLayout.createSequentialGroup()
                        .addGroup(ViewingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(SortByValue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SortOnlyNonProfits, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(WhatCategory, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(EditButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SearchFor)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SortByYear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(880, 880, 880))))
        );
        ViewingLayout.setVerticalGroup(
            ViewingLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ViewingLayout.createSequentialGroup()
                .addContainerGap(44, Short.MAX_VALUE)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(EditButton)
                .addGap(40, 40, 40)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(WhatCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(SearchFor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel9)
                .addGap(18, 18, 18)
                .addComponent(SortByYear, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49)
                .addComponent(SortOnlyNonProfits, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(SortByValue, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );

        javax.swing.GroupLayout ViewAndSortLayout = new javax.swing.GroupLayout(ViewAndSort);
        ViewAndSort.setLayout(ViewAndSortLayout);
        ViewAndSortLayout.setHorizontalGroup(
            ViewAndSortLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Viewing, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        ViewAndSortLayout.setVerticalGroup(
            ViewAndSortLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Viewing, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("View And Sort", ViewAndSort);

        EnterOrginization.setMaximumSize(new java.awt.Dimension(2767, 2767));
        EnterOrginization.setPreferredSize(new java.awt.Dimension(2298, 1087));

        nameOfOrginizationTextField.setForeground(new java.awt.Color(123, 139, 166));
        nameOfOrginizationTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameOfOrginizationTextFieldActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(244, 244, 244));
        jLabel1.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(60, 63, 65));
        jLabel1.setText("Name of Organization (required)");

        jLabel3.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(60, 63, 65));
        jLabel3.setText("Type of Organization");

        jLabel4.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(60, 63, 65));
        jLabel4.setText("Dollar Valuation (required)");

        dollarValuationTextField.setForeground(new java.awt.Color(123, 139, 166));
        dollarValuationTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dollarValuationTextFieldActionPerformed(evt);
            }
        });

        nameOfCEOTextField.setForeground(new java.awt.Color(123, 139, 166));
        nameOfCEOTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameOfCEOTextFieldActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(60, 63, 65));
        jLabel5.setText("Name of CEO (optional)");

        jLabel2.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(60, 63, 65));
        jLabel2.setText("Contact Email (required)");

        contactEmailTextField.setForeground(new java.awt.Color(123, 139, 166));
        contactEmailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactEmailTextFieldActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(60, 63, 65));
        jLabel6.setText("Contact Phone # (xxx-xxx-xxxx) (optional)");

        contactPhoneNumberTextField.setForeground(new java.awt.Color(123, 139, 166));
        contactPhoneNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactPhoneNumberTextFieldActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(60, 63, 65));
        jLabel7.setText("$");

        jLabel8.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(60, 63, 65));
        jLabel8.setText("Year of Founding (yyyy) (required)");

        yearOfFoundingTextField.setForeground(new java.awt.Color(123, 139, 166));
        yearOfFoundingTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearOfFoundingTextFieldActionPerformed(evt);
            }
        });

        isNonProfit.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        isNonProfit.setForeground(new java.awt.Color(60, 63, 65));
        isNonProfit.setText("NonProfit");
        isNonProfit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isNonProfitActionPerformed(evt);
            }
        });

        submitButton.setFont(new java.awt.Font("Osaka", 0, 24)); // NOI18N
        submitButton.setForeground(new java.awt.Color(123, 139, 166));
        submitButton.setText("Submit");
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Osaka", 0, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(60, 63, 65));
        jLabel11.setText("Enter an Organization");

        javax.swing.GroupLayout EnterOrginizationLayout = new javax.swing.GroupLayout(EnterOrginization);
        EnterOrginization.setLayout(EnterOrginizationLayout);
        EnterOrginizationLayout.setHorizontalGroup(
            EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EnterOrginizationLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                        .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, EnterOrginizationLayout.createSequentialGroup()
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(dollarValuationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(38, 38, 38)
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(contactPhoneNumberTextField)
                                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                        .addComponent(nameOfOrginizationTextField)
                                        .addGap(23, 23, 23)))
                                .addGap(23, 23, 23)
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(yearOfFoundingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(2, 2, 2))
                            .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 564, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(isNonProfit))
                                .addGap(46, 46, 46)
                                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nameOfCEOTextField)
                                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 558, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(EnterOrginizationLayout.createSequentialGroup()
                                .addComponent(contactEmailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 573, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(1109, 1109, 1109))))
        );
        EnterOrginizationLayout.setVerticalGroup(
            EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EnterOrginizationLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameOfOrginizationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(yearOfFoundingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(isNonProfit)
                    .addComponent(nameOfCEOTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(contactPhoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7))
                    .addComponent(dollarValuationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(EnterOrginizationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(EnterOrginizationLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(contactEmailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(65, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Enter Organization", EnterOrginization);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1213, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nameOfOrginizationTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameOfOrginizationTextFieldActionPerformed
        name = nameOfOrginizationTextField.getText();
    }//GEN-LAST:event_nameOfOrginizationTextFieldActionPerformed

    private void dollarValuationTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dollarValuationTextFieldActionPerformed
       dollarValuation = dollarValuationTextField.getText();
    }//GEN-LAST:event_dollarValuationTextFieldActionPerformed

    private void contactEmailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactEmailTextFieldActionPerformed
        contactEmail = contactEmailTextField.getText();
    }//GEN-LAST:event_contactEmailTextFieldActionPerformed

    private void contactPhoneNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactPhoneNumberTextFieldActionPerformed
                
    }//GEN-LAST:event_contactPhoneNumberTextFieldActionPerformed
    
    private void yearOfFoundingTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearOfFoundingTextFieldActionPerformed
        yearOfFounding = yearOfFoundingTextField.getText();
    }//GEN-LAST:event_yearOfFoundingTextFieldActionPerformed
    
    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        name = nameOfOrginizationTextField.getText();
        typeOfOrginization = isNonProfit.isSelected();
        dollarValuation = dollarValuationTextField.getText();
        contactEmail = contactEmailTextField.getText();
        yearOfFounding = yearOfFoundingTextField.getText();
        ceo = nameOfCEOTextField.getText();
        String entry = contactPhoneNumberTextField.getText();
        long longDollarValuation;
        dollarValuation = dollarValuation.replaceAll(",","");
        
        try{longDollarValuation = Long.parseLong(dollarValuation);}
        catch(NumberFormatException e){longDollarValuation = -1;}
        
        int intYearOfFounding;
        try{intYearOfFounding = Integer.parseInt(yearOfFounding);}
        catch(NumberFormatException e){intYearOfFounding = -1;}
        
        String nonProfitOrForProfit;
        if(typeOfOrginization){nonProfitOrForProfit = "Nonprofit";}
        else{nonProfitOrForProfit = "For Profit";}
        
        
        
        if (!entry.equals("")) {
            entry = entry.replaceAll("-", "");
            try {
                longContactPhoneNumber = Long.parseLong(entry);
                if (entry.length() != 10) {
                    longContactPhoneNumber = -1;
                    throw new NumberFormatException("Invalid phone number format");
                }
            } 
            catch (NumberFormatException e) {
                contactPhoneNumberTextField.setText("");
                submitButton.setText("Invalid phone number. Please enter a valid phone number.");
                return;
            }
        } 
        else {
            longContactPhoneNumber = 0;
        }
    
        if (!name.isEmpty() && longDollarValuation != -1 && !contactEmail.isEmpty() && intYearOfFounding != -1) {
            if (longContactPhoneNumber < 0) {
                contactPhoneNumberTextField.setText("");
                submitButton.setText("Invalid phone number.");
                return;
            }

            Organizations userInputedOrginization;
            if (!ceo.isEmpty()) {
                userInputedOrginization = new Organizations(name, nonProfitOrForProfit, longDollarValuation, contactEmail, 
                intYearOfFounding, ceo, longContactPhoneNumber);
            }
            else {
                userInputedOrginization = new Organizations(name, nonProfitOrForProfit, longDollarValuation, contactEmail, 
                intYearOfFounding, longContactPhoneNumber);
            }

            submitButton.setText("Accepted. Submit Another Entry?");
            nameOfOrginizationTextField.setText("");
            isNonProfit.setSelected(false);
            dollarValuationTextField.setText("");
            contactEmailTextField.setText("");
            yearOfFoundingTextField.setText("");
            nameOfCEOTextField.setText("");
            contactPhoneNumberTextField.setText("");
            saveToDatabase(userInputedOrginization);
        }
        else {
            submitButton.setText("Please enter required information");
            if(longDollarValuation == -1){submitButton.setText("Please enter number for company value");}
            if(intYearOfFounding == -1){submitButton.setText("Please enter number for year founded");}
        }
        populateTable();
    }//GEN-LAST:event_submitButtonActionPerformed

    private void nameOfCEOTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameOfCEOTextFieldActionPerformed
        ceo = nameOfCEOTextField.getText();
    }//GEN-LAST:event_nameOfCEOTextFieldActionPerformed
   
    public static String getDATABASE_URL()
    {
        return DATABASE_URL;
    }
   
    public static DefaultTableModel model = new DefaultTableModel();
    static JTable dataTable = new JTable(model);
    
    private void makeTable(){
        model.addColumn("Name");
        model.addColumn("Type");
        model.addColumn("Valuation");
        model.addColumn("Email");
        model.addColumn("Founding Year");
        model.addColumn("CEO");
        model.addColumn("Phone");
        model.addColumn("ID");
        JScrollPane scrollPane = new JScrollPane(dataTable);
        scrollPane.setBounds(350, 10, 800, 620);
        Viewing.add(scrollPane);
        validate();
    }
    
    public static void populateTable()
    {
        model.setRowCount(0);
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    String[] row = {
                            resultSet.getString("name"),
                            resultSet.getString("type_of_orginization"),
                            resultSet.getString("dollar_valuation"),
                            resultSet.getString("contact_email"),
                            resultSet.getString("year_of_founding"),
                            resultSet.getString("ceo"),
                            resultSet.getString("contact_phone_number"),
                            resultSet.getString("id")
                    };
                    model.addRow(row);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //populates the table in a certan order
    private void populateTable(String orderByClause) {
        model.setRowCount(0);
        currentlySearched = "";
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String query = "SELECT * FROM organizations";
            if (orderByClause != null && !orderByClause.isEmpty()) {
                query += " ORDER BY " + orderByClause;
            }
            try (Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                };
                    model.addRow(row);
                }
            }
        } catch (SQLException e) {
        }
    }
    
    //Used in the search function
    private void populateTableWithOnlyNameSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "name";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("name"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                };
                    model.addRow(row);
                    }
                }
            }
        } catch (SQLException e) {
        }
    }
   
    private void populateTableWithOnlyTypeSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "type_of_organization";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("type_of_orginization"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                    
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
   
    private void populateTableWithOnlyDollarValuationSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "dollar_valuation";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("dollar_valuation"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                    
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void populateTableWithOnlyContactEmailSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "contact_email";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("contact_email"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                    
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void populateTableWithOnlyYearSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "year_of_founding";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("year_of_founding"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                            
                    
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void populateTableWithOnlyCEOSearch(String orderByClause) {
    currentlySearched = "ceo";
    model.setRowCount(0);
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("ceo"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                            
                    
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void populateTableWithOnlyPhoneNumberSearch(String orderByClause) {
    model.setRowCount(0);
    currentlySearched = "contact_phone_number";
    try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
        String query = "SELECT * FROM organizations";
            try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    if(orderByClause.equals(resultSet.getString("contact_phone_number"))){
                    String[] row = {
                        resultSet.getString("name"),
                        resultSet.getString("type_of_orginization"),
                        resultSet.getString("dollar_valuation"),
                        resultSet.getString("contact_email"),
                        resultSet.getString("year_of_founding"),
                        resultSet.getString("ceo"),
                        resultSet.getString("contact_phone_number"),
                        resultSet.getString("id")
                            
                };
                    model.addRow(row);
                }}
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //
    
    
    
    private void isNonProfitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isNonProfitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isNonProfitActionPerformed

    int countValue = 0;
    private void SortByValueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortByValueActionPerformed

        if(countValue%2 != 0){populateTable("cast(dollar_valuation as long) ASC");}
        else{populateTable("cast(dollar_valuation as long) DESC");}
        countValue++;
    }//GEN-LAST:event_SortByValueActionPerformed

    int countNonProfit = 0;
    private void SortOnlyNonProfitsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortOnlyNonProfitsActionPerformed
        if(countNonProfit%2 != 0){populateTable("type_of_orginization = 'Nonprofit'");}
        else{populateTable("type_of_orginization = 'For Profit'");}
        countNonProfit++;
    }//GEN-LAST:event_SortOnlyNonProfitsActionPerformed

    int countYear = 0;
    private void SortByYearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortByYearActionPerformed
        if(countYear%2 != 0){populateTable("cast(year_of_founding as int) ASC");}
        else{populateTable("cast(year_of_founding as int) DESC");}
        countYear++;
    }//GEN-LAST:event_SortByYearActionPerformed

    private void WhatCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WhatCategoryActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_WhatCategoryActionPerformed

    private void SearchForActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchForActionPerformed
        String [] allPosiblilities = {"Everything","name", "type_of_orginization", "dollar_valuation", "contact_email",
            "year_of_founding", "ceo", "contact_phone_number"};
        int index = WhatCategory.getSelectedIndex();
        String userInput = SearchFor.getText();
        if(index == 0){populateTable();}
        if (index == 1){populateTableWithOnlyNameSearch(userInput);}
        if (index == 2){populateTableWithOnlyTypeSearch(userInput);}
        if (index == 3){populateTableWithOnlyDollarValuationSearch(userInput);}
        if (index == 4){populateTableWithOnlyContactEmailSearch(userInput);}
        if (index == 5){populateTableWithOnlyYearSearch(userInput);}
        if (index == 6){populateTableWithOnlyCEOSearch(userInput);}
        if (index == 7){populateTableWithOnlyPhoneNumberSearch(userInput);}
        
        
        
    }//GEN-LAST:event_SearchForActionPerformed

    private void EditButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditButtonActionPerformed
        if(dataTable.getSelectedRow()!= -1)
        {
            int row = dataTable.getSelectedRow();
            String rowID = dataTable.getValueAt(row, 7).toString();
            int parsedInt = Integer.parseInt(rowID);
            System.out.println(parsedInt);
            EditWindow window = new EditWindow(parsedInt);
            window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            window.setVisible(true);
         }
    }//GEN-LAST:event_EditButtonActionPerformed
         
    private void saveToDatabase(Organizations org) {
        
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String query = "INSERT INTO organizations (name, type_of_orginization, dollar_valuation, contact_email,"
                    + " year_of_founding, ceo, contact_phone_number, id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, org.getName());
                preparedStatement.setString(2, org.getTypeOfOrginization());
                preparedStatement.setLong(3, org.getDollarValuation());
                preparedStatement.setString(4, org.getContactEmail());
                preparedStatement.setInt(5, org.getYearOfFounding());
                preparedStatement.setString(6, org.getCeo());
                preparedStatement.setLong(7, org.getContactPhoneNumber());
                preparedStatement.executeUpdate();
                FirstProject.companiesAndOrginizations.add(org);
                
                System.out.println("Record for: "+org.getName()+" inserted successfully.");
            }
        } catch (SQLException e) {

        }
    }
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EditButton;
    private javax.swing.JPanel EnterOrginization;
    private javax.swing.JTextField SearchFor;
    private javax.swing.JButton SortByValue;
    private javax.swing.JButton SortByYear;
    private javax.swing.JButton SortOnlyNonProfits;
    private javax.swing.JPanel ViewAndSort;
    private javax.swing.JPanel Viewing;
    private javax.swing.JComboBox<String> WhatCategory;
    private javax.swing.JTextField contactEmailTextField;
    private javax.swing.JTextField contactPhoneNumberTextField;
    private javax.swing.JTextField dollarValuationTextField;
    private javax.swing.JCheckBox isNonProfit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField nameOfCEOTextField;
    private javax.swing.JTextField nameOfOrginizationTextField;
    private javax.swing.JButton submitButton;
    private javax.swing.JTextField yearOfFoundingTextField;
    // End of variables declaration//GEN-END:variables

}
