
package com.mycompany.firstproject;

public class Organizations 
{
    private String name;
    private String typeOfOrginization;
    private long dollarValuation;
    private String contactEmail;
    private int yearOfFounding;
    private String ceo;
    private long contactPhoneNumber;
    
    public Organizations(String name, String typeOfOrginization, long dollarValuation, String contactEmail, int yearFounded, String ceo, long contactPhoneNumber)
    {//Full constructor
        this.name = name;
        this.typeOfOrginization = typeOfOrginization;
        this.dollarValuation = dollarValuation;
        this.contactEmail = contactEmail;
        this.yearOfFounding = yearFounded;
        this.ceo = ceo;
        this.contactPhoneNumber = contactPhoneNumber;
    }
    public Organizations(String name, String typeOfOrginization, long dollarValuation, String contactEmail, int yearFounded)
    {//Minimum Contructor
        this.name = name;
        this.typeOfOrginization = typeOfOrginization;
        this.dollarValuation = dollarValuation;
        this.contactEmail = contactEmail;
        this.yearOfFounding = yearFounded;
    }
    public Organizations(String name, String typeOfOrginization, long dollarValuation, String contactEmail, int yearFounded, String ceo)
    {//Min with CEO
        this.name = name;
        this.typeOfOrginization = typeOfOrginization;
        this.dollarValuation = dollarValuation;
        this.contactEmail = contactEmail;
        this.yearOfFounding = yearFounded;
        this.ceo = ceo;
    }
    public Organizations(String name, String typeOfOrginization, long dollarValuation, String contactEmail, int yearFounded, long contactPhoneNumber) 
    {//Min with Phone number
        this.name = name;
        this.typeOfOrginization = typeOfOrginization;
        this.dollarValuation = dollarValuation;
        this.contactEmail = contactEmail;
        this.yearOfFounding = yearFounded;
        this.contactPhoneNumber = contactPhoneNumber;
    }
    
    public void setName(String n)
    {
        name = n;
    }
    public void setTypeOfOrginization(String tOO)
    {
        typeOfOrginization = tOO;
    }
    public void setDollarValuation(long dV)
    {
        dollarValuation = dV;
    }
    public void setContactEmail(String cE)
    {
        contactEmail = cE;
    }
    public void setYearOfFounding(int yOF)
    {
        yearOfFounding = yOF;
    }
    public void setCeo(String Ceo)
    {
        ceo = Ceo;
    }
    public void setContactPhoneNumber(long cPN)
    {
        contactPhoneNumber = cPN;
    }
    
    
    
    public String getName()
    {
        return name;
    }
    public String getTypeOfOrginization()
    {
        return typeOfOrginization;
    }
    public long getDollarValuation()
    {
        return dollarValuation;
    }
    public String getContactEmail()
    {
        return contactEmail;
    }
    public int getYearOfFounding()
    {
        return yearOfFounding;
    }
    public String getCeo()
    {
        return ceo;
    }
    public long getContactPhoneNumber()
    {
        return contactPhoneNumber;
    }
    
}
