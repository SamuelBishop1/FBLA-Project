package com.mycompany.firstproject;

import com.mycompany.firstproject.Organizations;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * @author sambishop
 */
public class EditWindow extends javax.swing.JFrame {
    int thisClassesRowSelected;
    public EditWindow(int rowSelected) {
        initComponents();
        try(Connection connection = DriverManager.getConnection("jdbc:sqlite:Libraries/organizations.db")){
            String query = "SELECT * FROM organizations WHERE id=" + rowSelected;
            Statement statement = connection.createStatement();
            try(ResultSet resultSet = statement.executeQuery(query)){
                while (resultSet.next()) {
                    if (resultSet.getString("id").equals((rowSelected)+"")){
                        nameOfOrginizationTextField.setText(resultSet.getString("name"));
                        if(resultSet.getString("type_of_orginization").equals("Nonprofit")){isNonProfit.setSelected(true);}else {isNonProfit.setSelected(false);}
                        dollarValuationTextField.setText(resultSet.getString("dollar_valuation"));
                        contactEmailTextField.setText(resultSet.getString("contact_email"));
                        yearOfFoundingTextField.setText(resultSet.getString("year_of_founding"));
                        nameOfCEOTextField.setText(resultSet.getString("ceo"));
                        contactPhoneNumberTextField.setText(resultSet.getString("contact_phone_number"));
                    }
                }
            } catch (SQLException e) {
            System.err.println("Error executing query: " + e.getMessage());
        }
    } catch (SQLException e) {
        System.err.println("Error connecting to the database: " + e.getMessage());
    }
        
        
        
        
        
        thisClassesRowSelected = rowSelected;
        setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        nameOfOrginizationTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        isNonProfit = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        dollarValuationTextField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        contactEmailTextField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        yearOfFoundingTextField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        nameOfCEOTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        contactPhoneNumberTextField = new javax.swing.JTextField();
        submitButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Name of Orginization (required)");

        nameOfOrginizationTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameOfOrginizationTextFieldActionPerformed(evt);
            }
        });

        jLabel3.setText("Type of Orginization");

        isNonProfit.setText("NonProfit");
        isNonProfit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isNonProfitActionPerformed(evt);
            }
        });

        jLabel4.setText("Dollar Valuation (required)");

        dollarValuationTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dollarValuationTextFieldActionPerformed(evt);
            }
        });

        jLabel2.setText("Contact Email (required)");

        contactEmailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactEmailTextFieldActionPerformed(evt);
            }
        });

        jLabel8.setText("Year of Founding (yyyy) (required)");

        yearOfFoundingTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearOfFoundingTextFieldActionPerformed(evt);
            }
        });

        jLabel5.setText("Name of CEO (optional)");

        nameOfCEOTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameOfCEOTextFieldActionPerformed(evt);
            }
        });

        jLabel6.setText("Contact Phone # (xxx-xxx-xxxx) (optional)");

        contactPhoneNumberTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactPhoneNumberTextFieldActionPerformed(evt);
            }
        });

        submitButton2.setText("Submit");
        submitButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(isNonProfit)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(118, 118, 118))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(nameOfOrginizationTextField)
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(yearOfFoundingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nameOfCEOTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(17, 17, 17))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(contactEmailTextField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dollarValuationTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(31, 31, 31))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(contactPhoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(submitButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
                    .addGap(289, 289, 289)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearOfFoundingTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nameOfOrginizationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameOfCEOTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(isNonProfit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(contactPhoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dollarValuationTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(submitButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(contactEmailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(299, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private static final String DATABASE_URL = "jdbc:sqlite:Libraries/organizations.db";
    private String name;
    private boolean typeOfOrginization;
    private String dollarValuation;
    private String ceo;
    private String contactEmail;
    private String contactPhoneNumber;
    private String yearOfFounding;
    long longContactPhoneNumber = 0;
    String currentlySearched = "";
    
    private void nameOfOrginizationTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameOfOrginizationTextFieldActionPerformed
        name = nameOfOrginizationTextField.getText();
    }//GEN-LAST:event_nameOfOrginizationTextFieldActionPerformed

    private void isNonProfitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isNonProfitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isNonProfitActionPerformed

    private void dollarValuationTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dollarValuationTextFieldActionPerformed
        dollarValuation = dollarValuationTextField.getText();
    }//GEN-LAST:event_dollarValuationTextFieldActionPerformed

    private void contactEmailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactEmailTextFieldActionPerformed
        contactEmail = contactEmailTextField.getText();
    }//GEN-LAST:event_contactEmailTextFieldActionPerformed

    private void yearOfFoundingTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearOfFoundingTextFieldActionPerformed
        yearOfFounding = yearOfFoundingTextField.getText();
    }//GEN-LAST:event_yearOfFoundingTextFieldActionPerformed

    private void nameOfCEOTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameOfCEOTextFieldActionPerformed
        ceo = nameOfCEOTextField.getText();
    }//GEN-LAST:event_nameOfCEOTextFieldActionPerformed

    private void contactPhoneNumberTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactPhoneNumberTextFieldActionPerformed

    }//GEN-LAST:event_contactPhoneNumberTextFieldActionPerformed

    private void submitButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButton2ActionPerformed
        
        
        name = nameOfOrginizationTextField.getText();
        typeOfOrginization = isNonProfit.isSelected();
        dollarValuation = dollarValuationTextField.getText();
        contactEmail = contactEmailTextField.getText();
        yearOfFounding = yearOfFoundingTextField.getText();
        ceo = nameOfCEOTextField.getText();
        String entry = contactPhoneNumberTextField.getText();
        long longDollarValuation;
        dollarValuation = dollarValuation.replaceAll(",","");
        
        try{longDollarValuation = Long.parseLong(dollarValuation);}
        catch(NumberFormatException e){longDollarValuation = -1;}
        
        int intYearOfFounding;
        try{intYearOfFounding = Integer.parseInt(yearOfFounding);}
        catch(NumberFormatException e){intYearOfFounding = -1;}
        
        String nonProfitOrForProfit;
        if(typeOfOrginization){nonProfitOrForProfit = "Nonprofit";}
        else{nonProfitOrForProfit = "For Profit";}
        
        
        
        if (!entry.equals("")&&!entry.equals("0")) {
            entry = entry.replaceAll("-", "");
            try {
                longContactPhoneNumber = Long.parseLong(entry);
                if (entry.length() != 10) {
                    longContactPhoneNumber = -1;
                    throw new NumberFormatException("Invalid phone number format");
                }
            } 
            catch (NumberFormatException e) {
                contactPhoneNumberTextField.setText("");
                submitButton2.setText("Invalid phone number. Please enter a valid phone number.");
                return;
            }
        } 
        else {
            longContactPhoneNumber = 0;
        }
    
        if (!name.isEmpty() && longDollarValuation != -1 && !contactEmail.isEmpty() && intYearOfFounding != -1) {
            if (longContactPhoneNumber < 0) {
                contactPhoneNumberTextField.setText("");
                submitButton2.setText("Invalid phone number.");
                return;
            }

            Organizations userInputedOrginization;
            if (!ceo.isEmpty()) {
                userInputedOrginization = new Organizations(name, nonProfitOrForProfit, longDollarValuation, contactEmail, intYearOfFounding, ceo, longContactPhoneNumber);
            }
            else {
                userInputedOrginization = new Organizations(name, nonProfitOrForProfit, longDollarValuation, contactEmail, intYearOfFounding, longContactPhoneNumber);
            }

            submitButton2.setText("Accepted. Submit Another Entry?");
            nameOfOrginizationTextField.setText("");
            isNonProfit.setSelected(false);
            dollarValuationTextField.setText("");
            contactEmailTextField.setText("");
            yearOfFoundingTextField.setText("");
            nameOfCEOTextField.setText("");
            contactPhoneNumberTextField.setText("");
            UpdateDatabase(userInputedOrginization);
        }
        else {
            submitButton2.setText("Please enter required information");
            if(longDollarValuation == -1){submitButton2.setText("Please enter number for company value");}
            if(intYearOfFounding == -1){submitButton2.setText("Please enter number for year founded");}
        }
       FirstProject.firstPage.populateTable();
       this.dispose();
    
    }//GEN-LAST:event_submitButton2ActionPerformed
    
    
    
    public void UpdateDatabase(Organizations org){
        try (Connection connection = DriverManager.getConnection(DATABASE_URL)) {
            String query = "UPDATE organizations SET name = ?, type_of_orginization = ?, dollar_valuation = ?, contact_email = ?, year_of_founding = ?, ceo = ?, contact_phone_number = ? WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, org.getName());
            preparedStatement.setString(2, String.valueOf(org.getTypeOfOrginization()));
            preparedStatement.setLong(3, org.getDollarValuation());
            preparedStatement.setString(4, org.getContactEmail());
            preparedStatement.setInt(5, org.getYearOfFounding());
            preparedStatement.setString(6, org.getCeo());
            preparedStatement.setLong(7, org.getContactPhoneNumber());
            preparedStatement.setInt(8, thisClassesRowSelected);
            preparedStatement.executeUpdate();
                    
            }catch (SQLException e) {
            e.printStackTrace();
        }
    
    }
        
    
 
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EditWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EditWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EditWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EditWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
 
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField contactEmailTextField;
    private javax.swing.JTextField contactPhoneNumberTextField;
    private javax.swing.JTextField dollarValuationTextField;
    private javax.swing.JCheckBox isNonProfit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField nameOfCEOTextField;
    private javax.swing.JTextField nameOfOrginizationTextField;
    private javax.swing.JButton submitButton2;
    private javax.swing.JTextField yearOfFoundingTextField;
    // End of variables declaration//GEN-END:variables
}
