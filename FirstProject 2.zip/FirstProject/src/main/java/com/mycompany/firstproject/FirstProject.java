package com.mycompany.firstproject;

import java.sql.SQLException;

import java.util.ArrayList;

public class FirstProject 
{
    static ArrayList <Organizations> companiesAndOrginizations = new ArrayList<Organizations>();
    
    public static NewJFrame firstPage = new NewJFrame();
    
    public static void main(String[] args) throws SQLException 
    {
        
        DatabaseConnection.connect();
        //DatabaseConnection.createTable();
        firstPage.setVisible(true);
    }
}
