package com.mycompany.firstproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {

    private static final String DATABASE_URL = "jdbc:sqlite:Libraries/organizations.db";
    private static final String ORGANIZATIONS_TABLE = "organizations";
    private static final String ID_COLUMN = "id";
    private static final String NAME_COLUMN = "name";
    private static final String TYPE_COLUMN = "type_of_orginization";
    private static final String DOLLAR_VALUATION_COLUMN = "dollar_valuation";
    private static final String CONTACT_EMAIL_COLUMN = "contact_email";
    private static final String YEAR_OF_FOUNDING_COLUMN = "year_of_founding";
    private static final String CEO_COLUMN = "ceo";
    private static final String CONTACT_PHONE_NUMBER_COLUMN = "contact_phone_number";

    public static Connection connect() {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");
            

            // Establish the database connection
            return DriverManager.getConnection(DATABASE_URL);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to connect to the database" + e.getMessage());
        }
    }
    public static void createTable()
    {
        try(Connection connection = connect(); Statement statment = connection.createStatement())
        {
            String createTableSQL = "CREATE TABLE organizations (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    "name TEXT not NULL,"+
                    "type_of_orginization TEXT,"+
                    "dollar_valuation TEXT,"+
                    "contact_email TEXT,"+
                    "year_of_founding TEXT,"+
                    "ceo TEXT,"+
                    "contact_phone_number TEXT" +
                    ")";
            
           statment.execute(createTableSQL);
           System.out.println("Table 'orginizations' created successfully.");
        }
        catch (SQLException e)
        {
            e.printStackTrace();
            throw new RuntimeException("Failed To create table: "+e.getMessage());
        
        }
    
    }
}

